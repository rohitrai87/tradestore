package com.deutsche.bank.tradestore.controller;

import java.util.List;
import java.util.Optional;
import com.deutsche.bank.tradestore.enums.TradeStoreStatus;
import com.deutsche.bank.tradestore.exception.InvalidTradeException;
import com.deutsche.bank.tradestore.model.Trade;
import com.deutsche.bank.tradestore.service.TradeStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tradeStore")
public class TradeStoreController {

    @Autowired
    private TradeStoreService tradeService;

    @RequestMapping("/addTrade")
    public TradeStoreStatus storeTrade(@RequestParam("trade") Trade trade) {

        // Checks if the trade is a valid trade
        TradeStoreStatus tradeStoreStatus = tradeService.isValidTrade(trade);

        // Saves the trade if valid otherwise throw InvalidTradeException
        if (TradeStoreStatus.SUCCESS.equals(tradeStoreStatus)) {
            tradeService.saveTrade(trade);
        } else if (TradeStoreStatus.VALID_TRADE_VERSION.equals(tradeStoreStatus)) {
            tradeService.updateTrade(trade);
        } else {
            throw new InvalidTradeException(trade, tradeStoreStatus.getMessage());
        }
        return tradeStoreStatus;
    }

    @RequestMapping("/getAllTrades")
    public List<Trade> findAllTrades() {
        return tradeService.findAllTrades();
    }

    @RequestMapping("/getTrade")
    public Optional<Trade> findTradeById(@RequestParam("tradeId") String tradeId) {
        return tradeService.findTradeById(tradeId);
    }
}
