package com.deutsche.bank.tradestore.repository;

import java.util.List;
import java.util.Optional;
import com.deutsche.bank.tradestore.model.Trade;

public interface TradeStoreRepository {

    void saveTrade(Trade trade);

    void updateTrade(Trade trade);

    List<Trade> findAllTrades();

    Optional<Trade> findTradeById(String tradeId);

}
