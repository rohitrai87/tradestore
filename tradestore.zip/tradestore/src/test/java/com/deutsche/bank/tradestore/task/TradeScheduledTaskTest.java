package com.deutsche.bank.tradestore.task;

import static org.awaitility.Awaitility.await;
import static org.awaitility.Durations.ONE_MINUTE;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;

@SpringBootTest()
class TradeScheduledTaskTest {

    @SpyBean
    private TradeScheduledTask tradeScheduledTask;

    @Test
    void testScehduledTask() {
        await().atMost(ONE_MINUTE).untilAsserted(() -> verify(tradeScheduledTask, atLeast(2)).expireTask());
    }

}
