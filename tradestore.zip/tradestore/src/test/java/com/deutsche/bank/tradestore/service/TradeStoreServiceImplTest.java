package com.deutsche.bank.tradestore.service;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.time.LocalDate;
import com.deutsche.bank.tradestore.TradeStoreMainApplication;
import com.deutsche.bank.tradestore.enums.TradeStoreStatus;
import com.deutsche.bank.tradestore.model.Trade;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig(TradeStoreMainApplication.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class TradeStoreServiceImplTest {

    @SpyBean
    private TradeStoreService tradeStoreService;

    @Test
    @Order(1)
    void testIsValid() {
        TradeStoreStatus status = tradeStoreService
                .isValidTrade(new Trade("T1", 3, "CP-1", "B1", LocalDate.of(2022, 7, 20), LocalDate.now(), "N"));
        assertSame(TradeStoreStatus.VALID_TRADE_VERSION, status);
    }

    @Test
    @Order(2)
    void testPersist() {
        tradeStoreService
                .saveTrade(new Trade("T8", 1, "CP-1", "B1", LocalDate.of(2022, 8, 25), LocalDate.now(), "N"));
        assertTrue(tradeStoreService.findTradeById("T8").isPresent());
    }

    @Test
    @Order(3)
    void testFindAll() {
        assertTrue(tradeStoreService.findAllTrades().size() > 0);
    }

}

