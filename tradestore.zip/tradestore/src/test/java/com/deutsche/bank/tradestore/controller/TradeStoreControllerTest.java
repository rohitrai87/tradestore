package com.deutsche.bank.tradestore.controller;

import com.deutsche.bank.tradestore.TradeStoreMainApplication;
import com.deutsche.bank.tradestore.enums.TradeStoreStatus;
import com.deutsche.bank.tradestore.exception.InvalidTradeException;
import com.deutsche.bank.tradestore.model.Trade;
import com.deutsche.bank.tradestore.service.TradeStoreService;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

@SpringJUnitConfig(TradeStoreMainApplication.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest()
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TradeStoreControllerTest {

    @SpyBean
    private TradeStoreController tradeStoreController;

    @SpyBean
    private TradeStoreService tradeStoreService;

    @Test
    @Order(1)
    void testStoreTrade() {
        TradeStoreStatus status = tradeStoreController
                .storeTrade(new Trade("T6", 2, "CP-1", "B1", LocalDate.of(2022, 7, 20), LocalDate.now(), "N"));
        assertSame(TradeStoreStatus.SUCCESS, status);
    }

    @Test
    @Order(2)
    void testInvalidTradeExceptionForVersion() {
        Trade trade = new Trade("T6", 1, "CP-1", "B1", LocalDate.of(2022, 5, 20), LocalDate.now(), "N");
        assertThrows(InvalidTradeException.class, () -> tradeStoreController.storeTrade(trade));
    }

    @Test
    @Order(3)
    void testInvalidTradeExceptionForMaturityDate() {
        Trade trade = new Trade("T6", 1, "CP-1", "B1", LocalDate.of(2021, 5, 20), LocalDate.now(), "N");
        assertThrows(InvalidTradeException.class, () -> tradeStoreController.storeTrade(trade));
    }

    @Test
    @Order(4)
    void testFindAllTrades() {
        assertTrue(tradeStoreController.findAllTrades().size() > 0);
    }

    @Test
    @Order(5)
    void testTradeWithSameVersion() {
        Trade trade = new Trade("T6", 2, "CP-1", "B1", LocalDate.of(2022, 7, 20), LocalDate.now(), "N");
        assertSame(TradeStoreStatus.VALID_TRADE_VERSION, tradeStoreController.storeTrade(trade));
        assertEquals(trade.getMaturityDate(), tradeStoreService.findTradeById("T6").get().getMaturityDate());
    }

    @Test
    @Order(6)
    void testFindTrade() {
        assertNotNull(tradeStoreController.findTradeById("T6"));
    }

}
