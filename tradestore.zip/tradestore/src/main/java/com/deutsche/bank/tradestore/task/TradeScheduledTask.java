package com.deutsche.bank.tradestore.task;

import java.util.Date;
import com.deutsche.bank.tradestore.service.TradeStoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

public class TradeScheduledTask {

    private static final Logger logger = LoggerFactory.getLogger(TradeScheduledTask.class);

    @Autowired
    private TradeStoreService tradeService;

    @Scheduled(cron = "0/10 * * * * ?")
    public void expireTask() {
        logger.info("Task triggred at {}", new Date());
        this.tradeService.expireTrade();
    }
}