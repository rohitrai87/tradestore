package com.deutsche.bank.tradestore.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import com.deutsche.bank.tradestore.enums.TradeExpiryFlag;
import com.deutsche.bank.tradestore.enums.TradeStoreStatus;
import com.deutsche.bank.tradestore.model.Trade;
import com.deutsche.bank.tradestore.repository.TradeStoreRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TradeStoreServiceImpl implements TradeStoreService {

    private static final Logger logger = LoggerFactory.getLogger(TradeStoreServiceImpl.class);

    @Autowired
    private TradeStoreRepository tradeStoreRepository;

    @Override
    public TradeStoreStatus isValidTrade(Trade trade) {
        logger.info("Checking validity of trade " + trade.getTradeId());
        TradeStoreStatus tradeStoreStatus = TradeStoreStatus.INVALID_MATURITY_DATE;

        // Check if the trade has valid maturity date otherwise return invalid maturity date status
        if (isMaturityDateValid(trade)) {
            logger.info("Trade " + trade.getTradeId() + " has valid maturity date");
            Optional<Trade> existingTrade = tradeStoreRepository.findTradeById(trade.getTradeId());
            if (existingTrade.isPresent()) {
                logger.info("Trade " + trade.getTradeId() + " is found!");
                tradeStoreStatus = isVersionValid(trade, existingTrade.get()) ? TradeStoreStatus.VALID_TRADE_VERSION
                        : TradeStoreStatus.INVALID_TRADE_VERSION;
            } else {
                logger.info("Trade " + trade.getTradeId() + " is not found!");
                tradeStoreStatus = TradeStoreStatus.SUCCESS;
            }
        }

        return tradeStoreStatus;
    }

    @Override
    public void saveTrade(Trade trade) {
        trade.setCreatedDate(LocalDate.now());
        tradeStoreRepository.saveTrade(trade);
    }

    @Override
    public void updateTrade(Trade trade) {
        tradeStoreRepository.updateTrade(trade);
    }

    @Override
    public List<Trade> findAllTrades() {
        return tradeStoreRepository.findAllTrades();
    }

    @Override
    public void expireTrade() {
        tradeStoreRepository.findAllTrades().stream().forEach(trade -> {
            if (!isMaturityDateValid(trade)) {
                trade.setExpiredFlag(TradeExpiryFlag.YES.getFlag());
                tradeStoreRepository.saveTrade(trade);
            }
        });
    }

    @Override
    public Optional<Trade> findTradeById(String tradeId) {
        return tradeStoreRepository.findTradeById(tradeId);
    }

    @Override
    public boolean isVersionValid(Trade newTrade, Trade oldTrade) {
        return (Integer.compare(newTrade.getVersion(), oldTrade.getVersion()) >= 0);
    }

    @Override
    public boolean isMaturityDateValid(Trade newTrade) {
        return newTrade.getMaturityDate().isAfter(LocalDate.now());
    }

}

