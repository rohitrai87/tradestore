package com.deutsche.bank.tradestore.exception;

import com.deutsche.bank.tradestore.model.Trade;

public class InvalidTradeException extends RuntimeException {

    private static final long serialVersionUID = 7843437894568177432L;

    private final Trade trade;

    public InvalidTradeException(final Trade trade, String message) {
        super(message);
        this.trade = trade;
    }

    public String getTradeId() {
        return trade.getTradeId();
    }
}