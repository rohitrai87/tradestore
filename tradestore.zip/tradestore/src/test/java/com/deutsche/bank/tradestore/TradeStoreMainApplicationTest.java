package com.deutsche.bank.tradestore;

import static org.junit.jupiter.api.Assertions.assertSame;
import java.time.LocalDate;
import com.deutsche.bank.tradestore.controller.TradeStoreController;
import com.deutsche.bank.tradestore.enums.TradeStoreStatus;
import com.deutsche.bank.tradestore.model.Trade;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;

@SpringBootTest
class TradeStoreMainApplicationTest {

    @SpyBean
    private TradeStoreController tradeStoreController;

    @Test
    void testTradeVersion() {
        TradeStoreStatus tradeStoreStatus = tradeStoreController
                .storeTrade(new Trade("T1", 2, "CP-1", "B1", LocalDate.of(2022, 7, 20), LocalDate.now(), "N"));
        assertSame(TradeStoreStatus.VALID_TRADE_VERSION, tradeStoreStatus);
    }

}