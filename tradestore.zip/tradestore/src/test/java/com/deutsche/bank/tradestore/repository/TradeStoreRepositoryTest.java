package com.deutsche.bank.tradestore.repository;

import com.deutsche.bank.tradestore.model.Trade;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TradeStoreRepositoryTest {

    @Autowired
    private TradeStoreRepository repository;

    @Test
    @Order(1)
    void testSaveTrade() {
        Trade trade = new Trade("T7", 1, "CP-1", "B1", LocalDate.of(2021, 5, 20), LocalDate.now(), "N");
        repository.saveTrade(trade);
    }

    @Test
    @Order(1)
    void testUpdateTrade() {
        Trade trade = new Trade("T7", 2, "CP-1", "B1", LocalDate.of(2021, 5, 20), LocalDate.now(), "N");
        repository.updateTrade(trade);
    }

    @Test
    @Order(2)
    void testFindAll() {
        List<Trade> trades = repository.findAllTrades();
        assertTrue(trades.size() > 0, "There should be trades present in the database!");
    }

    @Test
    @Order(3)
    void testFindTrade() {
        Optional<Trade> trade = this.repository.findTradeById("T1");
        assertTrue(trade.isPresent(), "T1 trade was found");
    }

}
