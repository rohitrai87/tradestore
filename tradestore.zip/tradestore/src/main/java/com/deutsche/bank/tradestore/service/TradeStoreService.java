package com.deutsche.bank.tradestore.service;

import com.deutsche.bank.tradestore.enums.TradeStoreStatus;
import com.deutsche.bank.tradestore.model.Trade;
import java.util.List;
import java.util.Optional;

public interface TradeStoreService {

    // Validates a trade
    public TradeStoreStatus isValidTrade(Trade trade);

    // persists the trade
    public void saveTrade(Trade trade);

    // update the existing trade
    public void updateTrade(Trade trade);

    // finds all trades
    public List<Trade> findAllTrades();

    // find a specific trade
    public Optional<Trade> findTradeById(String tradeId);

    // expires a trade
    public void expireTrade();

    // check trade version
    public boolean isVersionValid(Trade newTrade, Trade oldTrade);

    // validate maturity date
    public boolean isMaturityDateValid(Trade newTrade);

}

