package com.deutsche.bank.tradestore.enums;

public enum TradeStoreStatus {
    SUCCESS("Trade Persisted Successfully"), VALID_TRADE_VERSION("Valid Trade Version"),INVALID_MATURITY_DATE("Invalid Maturity Date"), INVALID_TRADE_VERSION("Invalid Trade Version");

    private final String message;

    TradeStoreStatus(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

}
