package com.deutsche.bank.tradestore.repository;

import com.deutsche.bank.tradestore.model.Trade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class TradeRepository implements TradeStoreRepository {

    private static final Logger logger = LoggerFactory.getLogger(TradeRepository.class);

    @Autowired
    JdbcTemplate jdbcTemplate;

    /* Adding a new trade into database table */
    @Override
    public void saveTrade(Trade trade) {
        String query = "INSERT INTO TRADE VALUES(?,?,?,?,?,?,?)";
        int result = jdbcTemplate.update(query, trade.getTradeId(), trade.getVersion(), trade.getCounterPartyId(),
                trade.getBookId(),trade.getMaturityDate(), trade.getCreatedDate(),trade.getExpiredFlag());
        if (result > 0) {
            logger.info("Trade stored successfully!");
        } else {
            logger.debug("Trade not stored in database");
        }
    }

    /* Updating an existing trade into database table */
    @Override
    public void updateTrade(Trade trade) {
        String query = "UPDATE TRADE SET VERSION = ?, COUNTERPARTYID = ?, BOOKID = ?, MATURITYDATE = ?, CREATEDDATE = ?, EXPIRYFLAG = ? WHERE TRADEID = ?";
        int result = jdbcTemplate.update(query, trade.getVersion(), trade.getCounterPartyId(),
                trade.getBookId(),trade.getMaturityDate(), trade.getCreatedDate(),trade.getExpiredFlag(), trade.getTradeId());
        if (result > 0) {
            logger.info("Trade updated successfully!");
        } else {
            logger.debug("Trade was not updated");
        }
    }

    /* Retrieving all trades from trade table */
    @Override
    public List<Trade> findAllTrades() {
        List<Trade> tradesList = jdbcTemplate.query("select tradeid, version, counterpartyid, bookid, maturitydate, createddate, expiryflag from trade", (result, rowNum) -> new Trade(result.getString("tradeid"),
                result.getInt("version"), result.getString("counterpartyid"),
                result.getString("bookid"), result.getDate("maturitydate").toLocalDate(),
                result.getDate("createddate").toLocalDate(), result.getString("expiryflag")));
        logger.info("Result returned from findAllTrades: " + tradesList);
        return tradesList;
    }

    /* Getting a specific trade by trade id from trade table */
    @Override
    public Optional<Trade> findTradeById(String tradeId) {
        try {
            String query = "SELECT TRADEID, VERSION, COUNTERPARTYID, BOOKID, MATURITYDATE, CREATEDDATE, EXPIRYFLAG FROM TRADE WHERE TRADEID = ? ";
            Trade trade = jdbcTemplate.queryForObject(query, new Object[]{tradeId}, new BeanPropertyRowMapper<>(Trade.class));
            return Optional.of(trade);
        } catch(EmptyResultDataAccessException emptyResultDataAccessException) {
            logger.debug("Trade was not found and hence returning an empty object");
            return Optional.empty();
        }
    }

}
